TRAIN_DIR = "brain_tumor_dataset_evolved/train/"
VAL_DIR = "brain_tumor_dataset_evolved/val/"
TEST_DIR = "brain_tumor_dataset_evolved/test/"
IMG_SIZE = (224, 224)
SEED = 99  # initial number or state used in random number generation algorithms
